#!/bin/bash

g++ -std=c++11 hw1.cpp -o hw1.o -w
./hw1.o
