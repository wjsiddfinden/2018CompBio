#!/bin/bash

rm hw2.o
g++ -std=c++11 hw2.cpp -o hw2.o -w
./hw2.o
